<?php
 //declarando a classe Item

 class Item
  {
  //definindo os atributos ou variáveis de instância
  public $nome;
  public $preco;
  public $categoria;

  //método que retorna a categoria do item
  function mostrarCategoria()
   {
   return $this->categoria; //NOTE BEM: dentro de um método, o uso de atributo nunca leva o $
   }

  //método que modifica o preço de um item
  function modificarPreco($novoPreco)
   {
   $this->preco = $novoPreco;
   }

  //método para mostrar o preço de um item
  function mostrarPreco()
   {
   return $this->preco;
   }
  }