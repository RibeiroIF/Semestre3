<!DOCTYPE html>
<html lang="pt-BR">
<head>
 <meta charset="UTF-8"> 
 <title> Aprendizado de POO com PHP </title>
 <link href="formata-form.css" rel="stylesheet">
</head>

<body>
 <h1> Atividade de aprendizado em POO com PHP - questão 1 </h1>

 <?php
  require "atividade1.inc.php";

  //criar um objeto livro
  $objLivro = new Livro();

  //aplicar o desconto e atualizar o preço
  $objLivro->calcularDesconto();

  //mostrar os dados
  $objLivro->mostrarDados();
 ?>
</body>
</html>