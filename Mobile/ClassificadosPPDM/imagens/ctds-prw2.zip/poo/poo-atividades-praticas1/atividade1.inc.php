<?php
 class Livro {
  public $titulo;
  public $autor;
  public $isbn;
  public $preco;
  public $percDesc;

  function __construct()
   {
   $formTitulo   = $_POST["titulo"];
   $formAutor    = $_POST["autor"];
   $formISBN     = $_POST["isbn"];
   $formPreco    = $_POST["preco"];
   $formPercDesc = $_POST["perc-desc"];
   
   //atribuindo os dados do formulário às variáveis de instância da classe
   $this->titulo   = $formTitulo;
   $this->autor    = $formAutor;
   $this->isbn     = $formISBN;
   $this->preco    = $formPreco;
   $this->percDesc = $formPercDesc;
   }

  function calcularDesconto()
   {
   $desconto = $this->preco * ($this->percDesc/100);
   $this->preco = $this->preco - $desconto;
   }

  function mostrarDados()
   {
   echo "<p> Dados atualizados do livro cadastrado, após o desconto: <br>
   Título = $this->titulo <br>
   Autor  = $this->autor <br>
   ISBN   = $this->isbn <br>
   Preço final = R$$this->preco </p>";
   }
 }