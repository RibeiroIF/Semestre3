<!DOCTYPE html>
<html lang="pt-BR">
<head>
 <meta charset="UTF-8"> 
 <title> Aprendizado de POO com PHP </title>
 <link href="formata-form.css" rel="stylesheet">
</head>

<body>
 <h1> Atividade de aprendizado em POO com PHP - questão 2 </h1>

 <?php
  require "atividade2.inc.php";
  
  $objCarro = new Carro();

  $classific = $objCarro->classificarCarro();

  $objCarro->mostrarInformacoes($classific);
 ?>
</body>
</html>