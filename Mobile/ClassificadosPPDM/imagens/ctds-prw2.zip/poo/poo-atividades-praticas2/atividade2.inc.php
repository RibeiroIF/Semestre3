<?php
 class Carro {
  public $fabricante;
  public $modelo;
  public $preco;

  function __construct()
   {
   $formFabric   = $_POST["fabric"];
   $formModelo   = $_POST["modelo"];
   $formPreco    = $_POST["preco"];
    
   $this->fabricante  = $formFabric;
   $this->modelo      = $formModelo;
   $this->preco       = $formPreco;
   }

  function classificarCarro()
   {
   if($this->preco < 100000)
    {
    $classificacao = "Carro popular";
    }
   elseif($this->preco <= 300000)
    {
    $classificacao = "Carro com performance intermediária";
    }
   else
    {
    $classificacao = "Carro de alta performance";
    }
   return $classificacao;
   }

  function mostrarInformacoes($classificacao)
   {
   if($classificacao == "Carro popular")
    {
    $preco = number_format($this->preco, 2, ",", ".");
    echo "<p> Dados do objeto carro criado: <br>
    Classificação = $classificacao <br>
    Fabricante = $this->fabricante <br>
    Modelo = $this->modelo <br>
    Preço de venda = R$$preco </p>";
    }
   else 
    {
    echo "<p> Segundo os dados fornecidos, o carro não se classifica como carro popular. Nenhuma informação disponível. </p>";
    } 
   }
 }