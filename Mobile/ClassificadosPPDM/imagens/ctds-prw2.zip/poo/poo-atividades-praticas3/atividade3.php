<!DOCTYPE html>
<html lang="pt-BR">
<head>
 <meta charset="UTF-8"> 
 <title> Aprendizado de POO com PHP </title>
 <link href="formata-form.css" rel="stylesheet">
</head>

<body>
 <h1> Atividade de aprendizado em POO com PHP - questão 3 </h1>

 <?php
  require "atividade3.inc.php";
  
  $objItem = new Item();

  $desc = $objItem->calcularDesconto();

  $objItem->mostrarPrecoFinal($desc);
 ?>
</body>
</html>