<?php
 class Item {
  public $nome;
  public $classificacao;
  public $preco;

  function __construct()
   {
   $this->nome          = $_POST["item"];
   $this->preco         = $_POST["preco"];
   $this->classificacao = $_POST["classific"];
   }

  function calcularDesconto()
   {
   define("DESC1", 5/100);
   define("DESC2", 7/100);

   if($this->classificacao == "hardware")
    {
    $desc = $this->preco * DESC1;
    } 
   else
    {
    $desc = $this->preco * DESC2;
    }
   
   echo "<p> Dados do item: <br>
             Classificação = $this->classificacao <br>
             Valor do desconto = R$$desc </p>";
   
   return $desc;
   }

  function mostrarPrecoFinal($desconto)
   {
    $precoFinal = $this->preco - $desconto;
    echo "<p> Após o desconto aplicado, o preço final do item é = R$$precoFinal </p>"; 
   }
 }