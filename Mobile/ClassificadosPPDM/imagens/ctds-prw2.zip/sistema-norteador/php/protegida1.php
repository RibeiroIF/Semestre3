<!DOCTYPE html>
<html lang="pt-BR">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title> Conteúdo restrito - página 1 </title>
 <link rel="stylesheet" href="../css/formata-lavacao.css">
</head>

<body>
 <?php
  require "../includes/criar-classe-conexao.inc.php";
  $banco = new BancoDeDados("localhost", "root", "", "sistema_lavacao", "clientes", "veiculos", "administrador");
  $estaLogado = $banco->testarSessao();
  if(!$estaLogado)
   {
   exit("<p> Você não está logado! <a href='../html/home.html'> Logar </a> </p>");
   }
 ?>
 
 <h1> Bem-vindo, caro usuário ou administrador! Sinta-se à vontade para explorar e utilizar todo o conteúdo restrito, que você acessa neste momento, de nossa aplicação web. </h1>

 <form action="../php/logout.php" method="post">
  <fieldset class="formata-diferente">
   <legend> Desconectar usuário ou administrador </legend>
   <button> Logout do sistema </button>
  </fieldset>
 </form>
</body>
</html>