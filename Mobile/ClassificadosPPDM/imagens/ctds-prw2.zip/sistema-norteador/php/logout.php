<?php
 require "../includes/criar-classe-conexao.inc.php";
 $banco = new BancoDeDados("localhost", "root", "", "sistema_lavacao", "clientes", "veiculos", "administrador");
  $banco->logout();