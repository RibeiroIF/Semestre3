<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
  <meta charset="utf-8"> 
  <title> Sistemas Norteador - protótipo de aplicação web para lavação de automóveis  </title> 
  <link rel="stylesheet" href="../css/formata-lavacao.css">
</head> 

<body>
 <?php
  require "../includes/criar-classe-conexao.inc.php";
  require "../includes/criar-classe-administrador.inc.php";

  $banco = new BancoDeDados("localhost", "root", "", "sistema_lavacao", "clientes", "veiculos", "administrador");

  $conexao = $banco->criarConexao();
  $banco->criarBanco($conexao);
  $banco->abrirBanco($conexao);
  $banco->definirCharset($conexao);
  $banco->criarTabelaAdministrador($conexao);

  $admin = new Administradores();

  $admin->definirCredenciais($conexao, $banco->nomeDaTabelaAdmin);

  $admin->logar($conexao, $banco->nomeDaTabelaAdmin);
 ?>
 </body>
 </html>